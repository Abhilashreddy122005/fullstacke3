-- Create database and tables
CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  sku VARCHAR(100) UNIQUE,
  quantity INT NOT NULL DEFAULT 0,
  location VARCHAR(255),
  description TEXT,
  user_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample admin user (password: admin123)
INSERT INTO users (username, password, email) VALUES
('admin', 'admin123', 'admin@inventory.com');

-- Sample data
INSERT INTO items (name, sku, quantity, location, description, user_id) VALUES
('Widget A', 'WIDGET-A', 100, 'Shelf 1A', 'High-quality standard widget', 1),
('Widget B', 'WIDGET-B', 50, 'Shelf 2B', 'Premium widget variant', 1),
('Gadget C', 'GAD-C-001', 200, 'Bin 3', 'Essential gadget', 1);
