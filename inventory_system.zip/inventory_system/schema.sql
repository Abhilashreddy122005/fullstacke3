-- ============================================================
-- COMPLETE INVENTORY MANAGEMENT SYSTEM - FRESH START
-- ============================================================
-- Run this ENTIRE script in MySQL Workbench
-- ============================================================

-- Create Database
DROP DATABASE IF EXISTS inventory_db;
CREATE DATABASE inventory_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventory_db;

-- ============================================================
-- USERS TABLE - For authentication and user management
-- ============================================================
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  fullname VARCHAR(255) NOT NULL,
  role ENUM('admin', 'manager', 'user') DEFAULT 'user',
  manager_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_username (username),
  INDEX idx_email (email),
  INDEX idx_manager_id (manager_id)
);

-- ============================================================
-- WAREHOUSES TABLE - Storage locations
-- ============================================================
CREATE TABLE warehouses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  store VARCHAR(255),        -- e.g., store or branch name
  location VARCHAR(255),
  state VARCHAR(100),        -- state or province
  country VARCHAR(100),      -- country name
  capacity INT DEFAULT 1000,
  manager_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_name (name),
  INDEX idx_store (store)
);

-- ============================================================
-- INVENTORY TABLE - Product catalog
-- ============================================================
CREATE TABLE inventory (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  sku VARCHAR(100) UNIQUE NOT NULL,
  category VARCHAR(100),
  description TEXT,
  unit_price DECIMAL(10, 2) DEFAULT 0,
  reorder_level INT DEFAULT 10,
  user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sku (sku),
  INDEX idx_name (name),
  INDEX idx_user_id (user_id)
);

-- ============================================================
-- STOCK TABLE - Quantity tracking by warehouse
-- ============================================================
CREATE TABLE stock (
  id INT AUTO_INCREMENT PRIMARY KEY,
  inventory_id INT NOT NULL,
  warehouse_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 0,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE CASCADE,
  UNIQUE KEY unique_item_warehouse (inventory_id, warehouse_id),
  INDEX idx_inventory_id (inventory_id),
  INDEX idx_warehouse_id (warehouse_id)
);

-- ============================================================
-- STOCK_HISTORY TABLE - Audit trail for stock changes
-- ============================================================
CREATE TABLE stock_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  inventory_id INT NOT NULL,
  warehouse_id INT NOT NULL,
  old_quantity INT DEFAULT 0,
  new_quantity INT DEFAULT 0,
  change_type ENUM('add', 'remove', 'adjust', 'move') DEFAULT 'adjust',
  notes TEXT,
  changed_by INT,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE CASCADE,
  FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_inventory_id (inventory_id),
  INDEX idx_changed_at (changed_at)
);

-- ============================================================
-- SAMPLE DATA - INITIAL ADMIN USER & WAREHOUSES
-- ============================================================

-- Create initial admin user (YOU can login with this)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('admin', 'admin123', 'admin@inventory.com', 'System Administrator', 'admin', NULL);

-- ============================================================
-- LOCATION-BASED MANAGERS (assigned to Indian locations/states)
-- ============================================================

-- Location 1: CHENNAI (Tamil Nadu)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('mgr_chennai', 'mgr123', 'mgr.chennai@inventory.com', 'Chennai Manager (Tamil Nadu)', 'manager', NULL);

-- Location 2: MUMBAI (Maharashtra)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('mgr_mumbai', 'mgr123', 'mgr.mumbai@inventory.com', 'Mumbai Manager (Maharashtra)', 'manager', NULL);

-- Location 3: DELHI (Delhi NCR)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('mgr_delhi', 'mgr123', 'mgr.delhi@inventory.com', 'Delhi Manager (Delhi NCR)', 'manager', NULL);

-- Location 4: BANGALORE (Karnataka)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('mgr_bangalore', 'mgr123', 'mgr.bangalore@inventory.com', 'Bangalore Manager (Karnataka)', 'manager', NULL);

-- Location 5: HYDERABAD (Telangana)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('mgr_hyderabad', 'mgr123', 'mgr.hyderabad@inventory.com', 'Hyderabad Manager (Telangana)', 'manager', NULL);

-- ============================================================
-- STAFF USERS for each location (3 per manager)
-- ============================================================

-- Chennai Team (Manager ID: 2)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('user_ch_001', 'user123', 'ch001@inventory.com', 'Ravi Kumar - Chennai Warehouse', 'user', 2),
('user_ch_002', 'user123', 'ch002@inventory.com', 'Priya Sharma - Chennai Ops', 'user', 2),
('user_ch_003', 'user123', 'ch003@inventory.com', 'Arjun Singh - Chennai Stock', 'user', 2);

-- Mumbai Team (Manager ID: 3)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('user_mb_001', 'user123', 'mb001@inventory.com', 'Deepak Patel - Mumbai Hub 1', 'user', 3),
('user_mb_002', 'user123', 'mb002@inventory.com', 'Anjali Verma - Mumbai Hub 2', 'user', 3),
('user_mb_003', 'user123', 'mb003@inventory.com', 'Rohan Gupta - Mumbai Logistics', 'user', 3);

-- Delhi Team (Manager ID: 4)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('user_dl_001', 'user123', 'dl001@inventory.com', 'Vikram Singh - Delhi Main', 'user', 4),
('user_dl_002', 'user123', 'dl002@inventory.com', 'Neha Kapoor - Delhi East', 'user', 4),
('user_dl_003', 'user123', 'dl003@inventory.com', 'Sameer Khan - Delhi Ops', 'user', 4);

-- Bangalore Team (Manager ID: 5)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('user_bg_001', 'user123', 'bg001@inventory.com', 'Karthik Reddy - Bangalore Warehouse', 'user', 5),
('user_bg_002', 'user123', 'bg002@inventory.com', 'Divya Iyer - Bangalore Stock', 'user', 5),
('user_bg_003', 'user123', 'bg003@inventory.com', 'Suresh Kumar - Bangalore Audit', 'user', 5);

-- Hyderabad Team (Manager ID: 6)
INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES
('user_hyd_001', 'user123', 'hyd001@inventory.com', 'Krishna Rao - Hyderabad Hub', 'user', 6),
('user_hyd_002', 'user123', 'hyd002@inventory.com', 'Swathi Das - Hyderabad Ops', 'user', 6),
('user_hyd_003', 'user123', 'hyd003@inventory.com', 'Ramesh Nair - Hyderabad Stock', 'user', 6);

-- Create 5 sample warehouses assigned to India-based location managers
INSERT INTO warehouses (name, store, location, state, country, capacity, manager_id) VALUES
('Chennai Hub - South', 'Warehouse Block A', 'Zone 1 - Industrial Area', 'Tamil Nadu', 'India', 800, 2),
('Mumbai Central - West', 'Distribution Center', 'Zone 2 - Warehouse District', 'Maharashtra', 'India', 1200, 3),
('Delhi MainHub - North', 'Storage Complex', 'Zone 3 - NCR Industrial', 'Delhi', 'India', 950, 4),
('Bangalore Tech Hub', 'Logistics Center', 'Zone 4 - Tech Park Area', 'Karnataka', 'India', 700, 5),
('Hyderabad Express Hub', 'Fulfillment Center', 'Zone 5 - Outer Ring', 'Telangana', 'India', 600, 6);

-- ============================================================
-- SAMPLE INVENTORY & STOCK DATA
-- ============================================================

-- Sample inventory items created by admin (user_id = 1)
INSERT INTO inventory (name, sku, category, description, unit_price, reorder_level, user_id) VALUES
('Widget A - Standard', 'WIDGET-A-001', 'Electronics', '12V Standard Widget', 15.50, 20, 1),
('Widget B - Premium', 'WIDGET-B-001', 'Electronics', '12V Premium Widget with LED', 25.99, 15, 1),
('Gadget C - USB', 'GADGET-C-001', 'Accessories', 'USB Adapter Cable', 8.99, 50, 1),
('Component D - Motor', 'COMPONENT-D-001', 'Parts', 'AC Motor 3HP', 145.00, 5, 1),
('Supply E - Fasteners', 'SUPPLY-E-001', 'Hardware', 'Assorted Bolt Kit', 24.50, 100, 1);

-- Sample stock: distribute items across India-based warehouses
-- Warehouse 1 (Chennai) stock levels
INSERT INTO stock (inventory_id, warehouse_id, quantity) VALUES
(1, 1, 120),  -- Widget A in Chennai
(2, 1, 70),   -- Widget B in Chennai
(3, 1, 280),  -- Gadget C in Chennai
(4, 1, 10),   -- Motor in Chennai
(5, 1, 400);  -- Fasteners in Chennai

-- Warehouse 2 (Mumbai) stock levels
INSERT INTO stock (inventory_id, warehouse_id, quantity) VALUES
(1, 2, 180),  -- Widget A in Mumbai
(2, 2, 95),   -- Widget B in Mumbai
(3, 2, 350),  -- Gadget C in Mumbai
(4, 2, 15),   -- Motor in Mumbai
(5, 2, 600);  -- Fasteners in Mumbai

-- Warehouse 3 (Delhi) stock levels
INSERT INTO stock (inventory_id, warehouse_id, quantity) VALUES
(1, 3, 150),  -- Widget A in Delhi
(2, 3, 80),   -- Widget B in Delhi
(3, 3, 320),  -- Gadget C in Delhi
(4, 3, 12),   -- Motor in Delhi
(5, 3, 500);  -- Fasteners in Delhi

-- Warehouse 4 (Bangalore) stock levels
INSERT INTO stock (inventory_id, warehouse_id, quantity) VALUES
(1, 4, 95),   -- Widget A in Bangalore
(2, 4, 50),   -- Widget B in Bangalore
(3, 4, 220),  -- Gadget C in Bangalore
(4, 4, 8),    -- Motor in Bangalore
(5, 4, 350);  -- Fasteners in Bangalore

-- Warehouse 5 (Hyderabad) stock levels
INSERT INTO stock (inventory_id, warehouse_id, quantity) VALUES
(1, 5, 110),  -- Widget A in Hyderabad
(2, 5, 65),   -- Widget B in Hyderabad
(3, 5, 290),  -- Gadget C in Hyderabad
(4, 5, 9),    -- Motor in Hyderabad
(5, 5, 420);  -- Fasteners in Hyderabad

-- ============================================================
-- NOTES FOR SETUP & TEST ACCOUNTS - INDIA LOCATIONS
-- ============================================================
-- ADMIN ACCOUNT (full system access):
--    Username: admin
--    Password: admin123
--    Can: view all stock globally, create managers/users, manage all warehouses
--
-- LOCATION MANAGERS (each manages their regional warehouse & team):
--    Manager 1 - CHENNAI (Tamil Nadu):
--      Username: mgr_chennai
--      Password: mgr123
--      Manages: Chennai Hub - South
--      Team Size: 3 staff users
--
--    Manager 2 - MUMBAI (Maharashtra):
--      Username: mgr_mumbai
--      Password: mgr123
--      Manages: Mumbai Central - West
--      Team Size: 3 staff users
--
--    Manager 3 - DELHI (NCR):
--      Username: mgr_delhi
--      Password: mgr123
--      Manages: Delhi MainHub - North
--      Team Size: 3 staff users
--
--    Manager 4 - BANGALORE (Karnataka):
--      Username: mgr_bangalore
--      Password: mgr123
--      Manages: Bangalore Tech Hub
--      Team Size: 3 staff users
--
--    Manager 5 - HYDERABAD (Telangana):
--      Username: mgr_hyderabad
--      Password: mgr123
--      Manages: Hyderabad Express Hub
--      Team Size: 3 staff users
--
-- STAFF USERS (update stock for their manager's warehouse):
--    Chennai Team (Manager: mgr_chennai):
--      user_ch_001 / user123 - Ravi Kumar (Warehouse)
--      user_ch_002 / user123 - Priya Sharma (Operations)
--      user_ch_003 / user123 - Arjun Singh (Stock)
--
--    Mumbai Team (Manager: mgr_mumbai):
--      user_mb_001 / user123 - Deepak Patel (Hub 1)
--      user_mb_002 / user123 - Anjali Verma (Hub 2)
--      user_mb_003 / user123 - Rohan Gupta (Logistics)
--
--    Delhi Team (Manager: mgr_delhi):
--      user_dl_001 / user123 - Vikram Singh (Main)
--      user_dl_002 / user123 - Neha Kapoor (East)
--      user_dl_003 / user123 - Sameer Khan (Operations)
--
--    Bangalore Team (Manager: mgr_bangalore):
--      user_bg_001 / user123 - Karthik Reddy (Warehouse)
--      user_bg_002 / user123 - Divya Iyer (Stock)
--      user_bg_003 / user123 - Suresh Kumar (Audit)
--
--    Hyderabad Team (Manager: mgr_hyderabad):
--      user_hyd_001 / user123 - Krishna Rao (Hub)
--      user_hyd_002 / user123 - Swathi Das (Operations)
--      user_hyd_003 / user123 - Ramesh Nair (Stock)
--
-- WORKFLOW & PERMISSIONS:
-- Admin:   View all locations/stock globally, create managers, manage system
-- Manager: View team members, assign users to own warehouse, see location stock
-- User:    Update stock in manager's assigned warehouse (limited to quantities)
--
-- TEST SCENARIOS:
-- 1. Login as admin → view all 5 India warehouses, all stock globally
-- 2. Login as mgr_mumbai → see only Mumbai warehouse, create/manage Mumbai team
-- 3. Login as user_ch_001 → see only Chennai manager's warehouse, update quantities
-- 4. Check Location Dashboard → see location cards with manager, team, and stock stats
-- 5. Drill down into location → see detailed inventory breakdown per warehouse
--
-- FIRST TIME SETUP:
-- 1. Open http://localhost:3000
-- 2. Login with admin / admin123
-- 3. Navigate to Locations tab to see all India hubs
-- 4. Click on any location card to drill down into details
-- 5. Create additional managers or users as needed
--
-- ============================================================
-- ANALYTIC VIEWS (for reporting / graphs)
-- ============================================================
CREATE VIEW inventory_overview AS
SELECT i.id, i.name, i.sku,
       COALESCE(SUM(s.quantity),0) AS total_quantity,
       SUM(CASE WHEN s.quantity = 0 THEN 1 ELSE 0 END) AS out_of_stock_count,
       SUM(CASE WHEN s.quantity > 0 AND s.quantity < i.reorder_level THEN 1 ELSE 0 END) AS low_stock_count
FROM inventory i
LEFT JOIN stock s ON i.id = s.inventory_id
GROUP BY i.id;

CREATE VIEW warehouse_stock AS
SELECT w.id AS warehouse_id, w.name AS warehouse_name, w.store, w.state, w.country,
       i.id AS item_id, i.name AS item_name, s.quantity
FROM warehouses w
JOIN stock s ON w.id = s.warehouse_id
JOIN inventory i ON i.id = s.inventory_id;

-- ============================================================
-- VERIFICATION QUERIES (Run after setup)
-- ============================================================
-- Check all tables created:
-- SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='inventory_db';
--
-- Check warehouses:
-- SELECT * FROM warehouses;
--
-- Check user after registration:
-- SELECT id, username, email, fullname, role FROM users;
--
-- Check inventory items:
-- SELECT i.id, i.name, i.sku, u.username as created_by FROM inventory i JOIN users u ON i.user_id = u.id;
--
-- Check stock by warehouse:
-- SELECT i.name, i.sku, w.name as warehouse, s.quantity 
-- FROM stock s
-- JOIN inventory i ON s.inventory_id = i.id
-- JOIN warehouses w ON s.warehouse_id = w.id
-- ORDER BY i.name, w.name;
--
-- ============================================================
-- END OF SCRIPT
-- ============================================================
