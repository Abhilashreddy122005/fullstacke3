// Check if user is logged in
async function checkAuth() {
  try {
    const res = await fetch('/api/user');
    if (!res.ok) {
      window.location.href = '/login.html';
    } else {
      const data = await res.json();
      document.getElementById('usernameDisplay').textContent = data.username;
      window.currentRole = data.role;
      
      // show stock nav for all authenticated users
      const stocklink = document.querySelector('.sidebar-nav a[href="#stock"]');
      if (stocklink) stocklink.classList.remove('hidden');
      
      // show admin-only elements if role is admin
      if (data.role === 'admin') {
        document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
      }
      
      // show warehouses nav for admin/manager
      if (data.role === 'admin' || data.role === 'manager') {
        const whlink = document.querySelector('.sidebar-nav a[href="#warehouses"]');
        if (whlink) whlink.classList.remove('hidden');
      } else {
        document.getElementById('warehouseForm')?.classList.add('hidden');
      }
      
      // show users nav for admin/manager
      if (data.role === 'admin' || data.role === 'manager') {
        const uslink = document.querySelector('.sidebar-nav a[href="#users"]');
        if (uslink) uslink.classList.remove('hidden');
      }
      
      toggleRoleField();
    }
  } catch (err) {
    window.location.href = '/login.html';
  }
}

async function fetchItems(){
  const res = await fetch('/api/inventory');
  if (!res.ok) {
    if (res.status === 401) window.location.href = '/login.html';
    return [];
  }
  return res.json();
}

function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function getStatusBadge(qty) {
  if (qty === 0) return '<span class="status-badge status-critical">Out of Stock</span>';
  if (qty < 20) return '<span class="status-badge status-low">Low Stock</span>';
  return '<span class="status-badge status-ok">In Stock</span>';
}

function render(items){
  const tbody = document.querySelector('#itemsTable tbody');
  const emptyState = document.getElementById('emptyState');
  
  if (items.length === 0) {
    tbody.innerHTML = '';
    emptyState.style.display = 'block';
    updateStats([]);
    return;
  }
  
  emptyState.style.display = 'none';
  tbody.innerHTML = '';
  items.forEach(it=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${it.id}</td>
      <td><strong>${escapeHtml(it.name)}</strong></td>
      <td>${escapeHtml(it.sku || '-')}</td>
      <td>${it.quantity}</td>
      <td>${escapeHtml(it.location || '-')}</td>
      <td>${getStatusBadge(it.quantity)}</td>
      <td class="actions">
        <button data-id="${it.id}" class="btn btn-edit edit">✏️ Edit</button>
        <button data-id="${it.id}" class="btn btn-delete delete">🗑️ Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  updateStats(items);
}

let statsChart;
function updateStats(items) {
  const totalItems = items.length;
  const totalQuantity = items.reduce((sum, it) => sum + (it.quantity || 0), 0);
  const lowStock = items.filter(it => it.quantity < 20 && it.quantity > 0).length;
  
  document.getElementById('totalItems').textContent = totalItems;
  document.getElementById('totalQuantity').textContent = totalQuantity;
  document.getElementById('lowStock').textContent = lowStock;

  // draw chart
  const ctx = document.getElementById('statsChart');
  if (ctx) {
    const data = {
      labels: ['In Stock', 'Low Stock', 'Out of Stock'],
      datasets: [{
        label: 'Stock Status',
        data: [totalQuantity - lowStock, lowStock, items.filter(it=>it.quantity===0).length],
        backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
      }]
    };
    if (!statsChart) {
      statsChart = new Chart(ctx, { type: 'pie', data });
    } else {
      statsChart.data = data;
      statsChart.update();
    }
  }
}

// ------------------ Analytics (country/state) ------------------
async function fetchCountryStats() {
  const res = await fetch('/api/stats/countries');
  if (!res.ok) return [];
  return res.json();
}

async function fetchStateStats(country) {
  const url = country ? '/api/stats/states?country=' + encodeURIComponent(country) : '/api/stats/states';
  const res = await fetch(url);
  if (!res.ok) return [];
  return res.json();
}

function renderStatsChart(data, mode='global'){
  const ctx = document.getElementById('statsChart');
  if(!ctx) return;
  let labels = [], values = [], bg = [];
  if(mode === 'country'){
    labels = data.map(r=>r.country || 'Unknown');
    values = data.map(r=>Number(r.total_units || 0));
    bg = labels.map((_,i)=>['#4f46e5','#10b981','#f59e0b','#ef4444'][i%4]);
  } else if(mode === 'state'){
    labels = data.map(r=>(r.state? r.state + ' ('+ (r.country||'') +')' : 'Unknown'));
    values = data.map(r=>Number(r.total_units || 0));
    bg = labels.map((_,i)=>['#06b6d4','#8b5cf6','#f97316','#ef4444'][i%4]);
  } else {
    labels = ['In Stock','Low Stock','Out of Stock'];
    values = data;
    bg = ['#10b981','#f59e0b','#ef4444'];
  }

  const chartData = { labels, datasets: [{ label: 'Units', data: values, backgroundColor: bg }] };
  if (!statsChart) {
    statsChart = new Chart(ctx, { type: 'bar', data: chartData, options: { responsive:true } });
  } else {
    statsChart.config.type = 'bar';
    statsChart.data = chartData;
    statsChart.update();
  }
}

async function loadAnalyticsControls(){
  // populate countries from warehouses
  const wh = await fetchWarehouses();
  const countries = Array.from(new Set(wh.map(w=>w.country).filter(Boolean)));
  const countrySelect = document.getElementById('countrySelect');
  countrySelect.innerHTML = '<option value="">All Countries</option>' + countries.map(c=>`<option value="${c}">${c}</option>`).join('');
  // when stats mode changes
  document.getElementById('statsMode').addEventListener('change', async (e)=>{
    const mode = e.target.value;
    document.getElementById('countrySelect').style.display = mode === 'country' || mode === 'state' ? '' : 'none';
    document.getElementById('stateSelect').style.display = mode === 'state' ? '' : 'none';
    await refreshStatsView();
  });
  document.getElementById('countrySelect').addEventListener('change', async (e)=>{
    const country = e.target.value;
    // populate stateSelect
    const states = Array.from(new Set(wh.filter(w=> !country || w.country===country).map(w=>w.state).filter(Boolean)));
    document.getElementById('stateSelect').innerHTML = '<option value="">All States</option>' + states.map(s=>`<option value="${s}">${s}</option>`).join('');
    await refreshStatsView();
  });
  document.getElementById('stateSelect').addEventListener('change', refreshStatsView);
  // initial load
  await refreshStatsView();
}

async function refreshStatsView(){
  const mode = document.getElementById('statsMode').value;
  if(mode === 'country'){
    const data = await fetchCountryStats();
    renderStatsChart(data, 'country');
  } else if(mode === 'state'){
    const country = document.getElementById('countrySelect').value;
    const data = await fetchStateStats(country);
    renderStatsChart(data, 'state');
  } else {
    // global: use existing items summary
    const items = await fetchItems();
    const totalQuantity = items.reduce((s,it)=>s+(it.quantity||0),0);
    const lowStock = items.filter(it=>it.quantity>0 && it.quantity < 20).length;
    const outStock = items.filter(it=>it.quantity===0).length;
    renderStatsChart([totalQuantity - lowStock, lowStock, outStock], 'global');
  }
}


async function loadAndRender(){
  const items = await fetchItems();
  render(items);
}

// --- section navigation helpers ---
function showSection(id) {
  document.querySelectorAll('main .card').forEach(sec => sec.classList.add('hidden'));
  const section = document.getElementById(id);
  if (section) section.classList.remove('hidden');
  // update active nav link
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(a => a.classList.remove('active'));
  const link = document.querySelector(`.sidebar-nav a[href="#${id}"]`);
  if (link) link.classList.add('active');
}

// navigation click handling
document.querySelectorAll('.sidebar-nav .nav-item').forEach(link => {
  link.addEventListener('click', function(e) {
    const href = this.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const sec = href.slice(1);
      // if unauthorized section, server will reject later
      showSection(sec);
      if (sec === 'items') loadAndRender();
      if (sec === 'stats') loadAnalyticsControls();
      if (sec === 'stock') loadStockTable();
      if (sec === 'warehouses') loadWarehouses();
      if (sec === 'users') loadUsers();
    }
  });
});

// --- warehouse management ---
let warehouses = [];
async function fetchWarehouses() {
  const res = await fetch('/api/warehouses');
  if (!res.ok) {
    if (res.status === 401) window.location.href = '/login.html';
    return [];
  }
  return res.json();
}

function renderWarehouses(list) {
  const tbody = document.querySelector('#warehousesTable tbody');
  tbody.innerHTML = '';
  list.forEach(w => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${w.id}</td>
      <td>${escapeHtml(w.name)}</td>
      <td>${escapeHtml(w.store||'-')}</td>
      <td>${escapeHtml(w.location||'-')}</td>
      <td>${escapeHtml(w.state||'-')}</td>
      <td>${escapeHtml(w.country||'-')}</td>
      <td>${w.capacity||0}</td>
      <td class="actions">
        <button data-id="${w.id}" class="btn btn-edit w-edit">✏️</button>
        <button data-id="${w.id}" class="btn btn-delete w-delete">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function loadWarehouses() {
  warehouses = await fetchWarehouses();
  renderWarehouses(warehouses);
}

// warehouse form handling
const warehouseForm = document.getElementById('warehouseForm');
if (warehouseForm) {
  warehouseForm.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('warehouseId').value;
    const payload = {
      name: document.getElementById('w-name').value.trim(),
      store: document.getElementById('w-store').value.trim(),
      location: document.getElementById('w-location').value.trim(),
      state: document.getElementById('w-state').value.trim(),
      country: document.getElementById('w-country').value.trim(),
      capacity: Number(document.getElementById('w-capacity').value || 0)
    };
    try {
      if (id) {
        await fetch('/api/warehouses/' + id, { method: 'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      } else {
        await fetch('/api/warehouses', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      }
      resetWarehouseForm();
      await loadWarehouses();
    } catch (err) {
      alert('Error saving warehouse');
    }
  });
}

document.getElementById('w-resetBtn')?.addEventListener('click', resetWarehouseForm);
function resetWarehouseForm() {
  ['warehouseId','w-name','w-store','w-location','w-state','w-country','w-capacity'].forEach(id=>document.getElementById(id).value='');
}

// warehouse table buttons
document.querySelector('#warehousesTable')?.addEventListener('click', async (e)=>{
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  if(btn.classList.contains('w-delete')){
    if(!confirm('Delete this warehouse?')) return;
    try { await fetch('/api/warehouses/'+id, { method:'DELETE'}); await loadWarehouses(); }
    catch(err){alert('Error deleting warehouse');}
  }
  if(btn.classList.contains('w-edit')){
    const w = warehouses.find(x=>x.id==id);
    if(w){
      document.getElementById('warehouseId').value=w.id;
      document.getElementById('w-name').value=w.name;
      document.getElementById('w-store').value=w.store||'';
      document.getElementById('w-location').value=w.location||'';
      document.getElementById('w-state').value=w.state||'';
      document.getElementById('w-country').value=w.country||'';
      document.getElementById('w-capacity').value=w.capacity||0;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
});

// --- user management ---
let users = [];
async function fetchUsers(){
  const res = await fetch('/api/users');
  if (!res.ok) {
    if (res.status === 401) window.location.href = '/login.html';
    return [];
  }
  return res.json();
}
function renderUsers(list){
  const tbody = document.querySelector('#usersTable tbody');
  tbody.innerHTML='';
  list.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${u.id}</td>
      <td>${escapeHtml(u.fullname)}</td>
      <td>${escapeHtml(u.username)}</td>
      <td>${escapeHtml(u.email)}</td>
      <td>${escapeHtml(u.manager_name || '-')}</td>
      <td>${escapeHtml(u.role)}</td>
      <td class="actions">
        <button data-id="${u.id}" class="btn btn-edit u-edit">✏️</button>
        <button data-id="${u.id}" class="btn btn-delete u-delete">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}
async function loadUsers(){
  users = await fetchUsers();
  renderUsers(users);
}

// user form handling
const userForm = document.getElementById('userForm');
if (userForm) {
  userForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const id = document.getElementById('userId').value;
    const payload = {
      fullname: document.getElementById('u-fullname').value.trim(),
      username: document.getElementById('u-username').value.trim(),
      email: document.getElementById('u-email').value.trim(),
      password: document.getElementById('u-password').value.trim(),
      role: document.getElementById('u-role').value
    };
    try {
      if(id){
        // update without password
        await fetch('/api/users/'+id, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      } else {
        await fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      }
      resetUserForm();
      await loadUsers();
    } catch(err){
      alert('Error saving user');
    }
  });
}
document.getElementById('u-resetBtn')?.addEventListener('click', resetUserForm);
function resetUserForm(){
  ['userId','u-fullname','u-username','u-email','u-password'].forEach(id=>document.getElementById(id).value='');
    document.getElementById('u-role').value='user';
    // if manager, hide role selector
    toggleRoleField();
}

// hide/disable role field for managers
function toggleRoleField(){
  const roleField = document.getElementById('u-role');
  if (!roleField) return;
  if (window.currentRole === 'manager') {
    roleField.value = 'user';
    roleField.parentElement.style.display = 'none';
  } else {
    roleField.parentElement.style.display = '';
  }
}

// update role selector visibility when loading users for edit
function populateUserForm(u){
  document.getElementById('userId').value=u.id;
  document.getElementById('u-fullname').value=u.fullname;
  document.getElementById('u-username').value=u.username;
  document.getElementById('u-email').value=u.email;
  document.getElementById('u-role').value=u.role;
  toggleRoleField();
}

document.querySelector('#usersTable')?.addEventListener('click', async e => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  if (btn.classList.contains('u-delete')) {
    if (!confirm('Delete this user?')) return;
    try {
      await fetch('/api/users/' + id, { method: 'DELETE' });
      await loadUsers();
    } catch (err) {
      alert('Error deleting user');
    }
  }
  if (btn.classList.contains('u-edit')) {
    const u = users.find(x => x.id == id);
    if (u) {
      populateUserForm(u);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
});

// --- stock management (role-based) ---
let allStock = [];
async function fetchAllStock() {
  const res = await fetch('/api/all-stock');
  if (!res.ok) {
    if (res.status === 401) window.location.href = '/login.html';
    return [];
  }
  return res.json();
}

async function loadStockTable() {
  allStock = await fetchAllStock();
  renderStockTable(allStock);
  populateStockFilters();
}

function renderStockTable(stocks) {
  const tbody = document.querySelector('#stockTable tbody');
  const emptyState = document.getElementById('stockEmpty');
  
  if (stocks.length === 0) {
    tbody.innerHTML = '';
    emptyState.style.display = 'block';
    return;
  }
  
  emptyState.style.display = 'none';
  tbody.innerHTML = '';
  stocks.forEach(s => {
    const status = s.quantity === 0 ? '❌ Out' : s.quantity < s.reorder_level ? '⚠️ Low' : '✅ OK';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.sku)}</td>
      <td>${escapeHtml(s.warehouse_name)}</td>
      <td>${escapeHtml(s.manager_name || '-')}</td>
      <td>${escapeHtml(s.state || '-')} / ${escapeHtml(s.country || '-')}</td>
      <td>
        <input type="number" class="stock-qty" data-id="${s.id}" value="${s.quantity}" style="width:60px;">
      </td>
      <td>${status}</td>
      <td>
        <button class="btn btn-primary stock-update" data-id="${s.id}">💾</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  
  // Add click handlers for stock update buttons
  document.querySelectorAll('.stock-update').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const stockId = btn.dataset.id;
      const qtyInput = document.querySelector(`.stock-qty[data-id="${stockId}"]`);
      const newQty = Number(qtyInput.value);
      try {
        await fetch('/api/stock/' + stockId, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ quantity: newQty })
        });
        alert('Stock updated successfully!');
        await loadStockTable();
      } catch (err) {
        alert('Error updating stock: ' + err.message);
      }
    });
  });
}

function populateStockFilters() {
  // Populate warehouse filter
  const warehouses = Array.from(new Set(allStock.map(s => s.warehouse_name).filter(Boolean)));
  const whSelect = document.getElementById('stockWarehouse');
  const currentWh = whSelect.value;
  whSelect.innerHTML = '<option value="">All Warehouses</option>' + 
    warehouses.map(w => `<option value="${w}">${w}</option>`).join('');
  whSelect.value = currentWh;
  
  // Show manager filter only for admins
  if (window.currentRole === 'admin') {
    const managers = Array.from(new Set(allStock.map(s => s.manager_name).filter(Boolean)));
    const mgSelect = document.getElementById('stockManager');
    mgSelect.style.display = '';
    mgSelect.innerHTML = '<option value="">All Managers</option>' + 
      managers.map(m => `<option value="${m}">${m}</option>`).join('');
  }
}

// Stock filters
document.getElementById('stockWarehouse')?.addEventListener('change', filterStock);
document.getElementById('stockManager')?.addEventListener('change', filterStock);
document.getElementById('stockSearch')?.addEventListener('keyup', filterStock);

function filterStock() {
  const whFilter = document.getElementById('stockWarehouse')?.value || '';
  const mgFilter = document.getElementById('stockManager')?.value || '';
  const searchFilter = document.getElementById('stockSearch')?.value.toLowerCase() || '';
  
  const filtered = allStock.filter(s => {
    const whMatch = !whFilter || s.warehouse_name === whFilter;
    const mgMatch = !mgFilter || s.manager_name === mgFilter;
    const nameMatch = !searchFilter || s.name.toLowerCase().includes(searchFilter) || s.sku.toLowerCase().includes(searchFilter);
    return whMatch && mgMatch && nameMatch;
  });
  
  renderStockTable(filtered);
}

// Search functionality
let allItems = [];
document.getElementById('searchBox').addEventListener('keyup', (e) => {
  const query = e.target.value.toLowerCase();
  const filtered = allItems.filter(it => 
    it.name.toLowerCase().includes(query) || 
    (it.sku && it.sku.toLowerCase().includes(query))
  );
  render(filtered);
});

document.getElementById('itemForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const id = document.getElementById('itemId').value;
  const payload = {
    name: document.getElementById('name').value.trim(),
    sku: document.getElementById('sku').value.trim(),
    quantity: Number(document.getElementById('quantity').value || 0),
    location: document.getElementById('location').value.trim(),
    description: document.getElementById('description').value.trim()
  };
  
  if (!payload.name) {
    alert('Item name is required');
    return;
  }
  
  try {
    if(id){
      await fetch('/api/items/'+id, { method: 'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    } else {
      await fetch('/api/items', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    }
    resetForm();
    await loadAndRender();
    await refreshAllItems();
  } catch (err) {
    alert('Error saving item');
  }
});

document.getElementById('resetBtn').addEventListener('click', resetForm);

function resetForm(){
  document.getElementById('itemId').value='';
  ['name','sku','quantity','location','description'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('quantity').value = '0';
}

document.querySelector('#itemsTable').addEventListener('click', async (e)=>{
  const btn = e.target.closest('button');
  if (!btn) return;
  
  const id = btn.dataset.id;
  if(!id) return;
  
  if(btn.classList.contains('delete')){
    if(!confirm('Delete this item?')) return;
    try {
      await fetch('/api/items/'+id, { method: 'DELETE' });
      await loadAndRender();
      await refreshAllItems();
    } catch (err) {
      alert('Error deleting item');
    }
  }
  
  if(btn.classList.contains('edit')){
    try {
      const items = await fetchItems();
      const it = items.find(x=>x.id==id);
      if(it){
        document.getElementById('itemId').value = it.id;
        document.getElementById('name').value = it.name;
        document.getElementById('sku').value = it.sku || '';
        document.getElementById('quantity').value = it.quantity;
        document.getElementById('location').value = it.location || '';
        document.getElementById('description').value = it.description || '';
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      alert('Error loading item');
    }
  }
});

async function refreshAllItems() {
  allItems = await fetchItems();
}

// ============================================================
// LOCATIONS MANAGEMENT (India-based location dashboard)
// ============================================================

async function loadLocations() {
  try {
    const res = await fetch('/api/locations');
    if (!res.ok) throw new Error('Failed to load locations');
    const locations = await res.json();
    renderLocations(locations);
  } catch (err) {
    console.error('Error loading locations:', err);
    document.getElementById('locationsGrid').innerHTML = '<p>Error loading locations</p>';
  }
}

function renderLocations(locations) {
  const grid = document.getElementById('locationsGrid');
  if (!locations || locations.length === 0) {
    grid.innerHTML = '<p>No locations available</p>';
    return;
  }

  grid.innerHTML = locations.map(loc => `
    <div class="location-card" onclick="showLocationDetails(${loc.id})">
      <h3>${loc.state}</h3>
      <p><strong>Warehouse:</strong> ${loc.warehouse_name || 'N/A'}</p>
      <p><strong>Manager:</strong> ${loc.manager_name || 'Unassigned'}</p>
      <div class="location-meta">
        <div class="location-meta-item">
          <div class="meta-value">${loc.team_size || 0}</div>
          <div class="meta-label">Team Members</div>
        </div>
        <div class="location-meta-item">
          <div class="meta-value">${loc.total_stock || 0}</div>
          <div class="meta-label">Total Stock</div>
        </div>
        <div class="location-meta-item">
          <div class="meta-value">${loc.distinct_items || 0}</div>
          <div class="meta-label">Item Types</div>
        </div>
        <div class="location-meta-item">
          <div class="meta-value">📍</div>
          <div class="meta-label">Click Details</div>
        </div>
      </div>
    </div>
  `).join('');
}

async function showLocationDetails(locationId) {
  try {
    const res = await fetch(`/api/locations/${locationId}`);
    if (!res.ok) throw new Error('Failed to load location details');
    const data = await res.json();
    
    // Update modal header
    document.getElementById('locationTitle').textContent = `${data.warehouse.state} Location Hub`;
    
    // Update location info
    document.getElementById('locationName').textContent = data.warehouse.name || 'Warehouse';
    document.getElementById('locationState').textContent = data.warehouse.state || 'N/A';
    document.getElementById('locationManager').textContent = data.warehouse.manager_name || 'Unassigned';
    document.getElementById('locationCapacity').textContent = `${data.warehouse.capacity || 0} units`;
    document.getElementById('locationTeamSize').textContent = data.team.length;
    
    // Update stats
    document.getElementById('locationStockCount').textContent = data.stats.total_units || 0;
    document.getElementById('locationItemCount').textContent = data.stats.distinct_items || 0;
    document.getElementById('locationOutOfStock').textContent = data.stats.out_of_stock_items || 0;
    document.getElementById('locationLowStock').textContent = data.stats.low_stock_items || 0;
    
    // Render team members
    const teamList = document.getElementById('locationTeamList');
    if (data.team.length > 0) {
      teamList.innerHTML = data.team.map(member => `
        <div class="team-member">
          <strong>${member.fullname}</strong> <small>(${member.username})</small>
          <br><small>${member.email}</small>
        </div>
      `).join('');
    } else {
      teamList.innerHTML = '<p class="team-member">No team members assigned</p>';
    }
    
    // Render inventory
    const inventoryList = document.getElementById('locationInventoryList');
    if (data.stock.length > 0) {
      inventoryList.innerHTML = data.stock.map(item => `
        <div class="inventory-item">
          <div class="inventory-item-name">
            <strong>${item.name}</strong><br>
            <small>${item.sku} | ${item.category}</small>
          </div>
          <div class="inventory-item-qty">${item.quantity || 0}</div>
        </div>
      `).join('');
    } else {
      inventoryList.innerHTML = '<p class="inventory-item">No inventory items</p>';
    }
    
    // Show modal
    document.getElementById('locationModal').classList.remove('hidden');
  } catch (err) {
    console.error('Error loading location details:', err);
    alert('Failed to load location details');
  }
}

function closeLocationModal() {
  document.getElementById('locationModal').classList.add('hidden');
}

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeLocationModal();
});

// Show locations section - also load locations
document.addEventListener('click', (e) => {
  if (e.target.closest('a[href="#locations"]')) {
    loadLocations();
  }
});

// Show locations nav for admin/manager
async function initializeLocationNav() {
  if (window.currentRole === 'admin' || window.currentRole === 'manager') {
    const loclink = document.querySelector('.sidebar-nav a[href="#locations"]');
    if (loclink) loclink.classList.remove('hidden');
  }
}

document.getElementById('logoutBtn').addEventListener('click', async () => {
  try {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login.html';
  } catch (err) {
    alert('Logout failed');
  }
});

// Initialize
checkAuth();
setTimeout(initializeLocationNav, 500); // After auth check
showSection('items');
loadAndRender();
refreshAllItems();
