require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const path = require('path');
const session = require('express-session');

const app = express();
app.use(cors());
app.use(express.json());
app.use(session({
  secret: 'inventory_secret_key_12345',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 3600000 }
}));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'inventory_db',
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.use('/', express.static(path.join(__dirname, 'public')));

function checkAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Unauthorized. Please login.' });
  }
  next();
}

// ==================== AUTHENTICATION ====================

// Register new user (admin or manager)
// admin may create any role; manager may only create users and assign them to themselves
app.post('/api/register', checkAuth, async (req, res) => {
  const callerRole = req.session.role;
  const callerId = req.session.userId;
  if (!(callerRole === 'admin' || callerRole === 'manager')) {
    return res.status(403).json({ error: 'Only admin or manager can create users' });
  }
  try {
    const { fullname, username, email, password, role, manager_id } = req.body;
    
    if (!fullname || !username || !email || !password) {
      return res.status(400).json({ error: 'All fields required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const [existing] = await pool.query(
      'SELECT id FROM users WHERE username = ? OR email = ?',
      [username, email]
    );

    if (existing.length > 0) {
      return res.status(400).json({ error: 'Username or email already exists' });
    }

    let userRole = role || 'user';
    let assigned_manager_id = manager_id || null;
    
    // if manager is creating, force role to 'user' and assign to themselves
    if (callerRole === 'manager') {
      userRole = 'user';
      assigned_manager_id = callerId;
    }
    // admin can create any role; if creating a user, must specify or default to NULL manager
    
    await pool.query(
      'INSERT INTO users (username, password, email, fullname, role, manager_id) VALUES (?, ?, ?, ?, ?, ?)',
      [username, password, email, fullname, userRole, assigned_manager_id]
    );

    res.json({ success: true, message: 'Account created successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    req.session.userId = rows[0].id;
    req.session.username = rows[0].username;
    req.session.role = rows[0].role;
    req.session.managerId = rows[0].manager_id;
    res.json({ success: true, username: rows[0].username });
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Logout failed' });
    res.json({ success: true });
  });
});

app.get('/api/user', checkAuth, (req, res) => {
  res.json({ username: req.session.username, role: req.session.role });
});

// ==================== USER MANAGEMENT ====================
app.get('/api/users', checkAuth, async (req, res) => {
  const role = req.session.role;
  const userId = req.session.userId;
  try {
    let rows;
    if (role === 'admin') {
      // admin sees all users with manager name
      [rows] = await pool.query(`
        SELECT u.id, u.username, u.email, u.fullname, u.role, u.manager_id, 
               m.fullname as manager_name, u.created_at 
        FROM users u 
        LEFT JOIN users m ON u.manager_id = m.id
        ORDER BY u.role DESC, u.fullname ASC
      `);
    } else if (role === 'manager') {
      // manager sees only their assigned users
      [rows] = await pool.query(`
        SELECT id, username, email, fullname, role, manager_id, created_at 
        FROM users 
        WHERE manager_id = ? 
        ORDER BY fullname ASC
      `, [userId]);
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.put('/api/users/:id', checkAuth, async (req, res) => {
  const caller = req.session.role;
  const id = req.params.id;
  try {
    const { fullname, username, email, role } = req.body;
    if (caller === 'admin') {
      await pool.query('UPDATE users SET fullname=?, username=?, email=?, role=? WHERE id = ?', [fullname, username, email, role, id]);
    } else if (caller === 'manager') {
      // managers may only update regular users and cannot change role
      const [u] = await pool.query('SELECT role FROM users WHERE id = ?', [id]);
      if (u.length === 0 || u[0].role !== 'user') return res.status(403).json({ error: 'Forbidden' });
      await pool.query('UPDATE users SET fullname=?, username=?, email=? WHERE id = ?', [fullname, username, email, id]);
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const [rows] = await pool.query('SELECT id, username, email, fullname, role FROM users WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Update failed' });
  }
});

app.delete('/api/users/:id', checkAuth, async (req, res) => {
  const caller = req.session.role;
  const id = req.params.id;
  try {
    if (caller === 'admin') {
      await pool.query('DELETE FROM users WHERE id = ?', [id]);
    } else if (caller === 'manager') {
      const [u] = await pool.query('SELECT role FROM users WHERE id = ?', [id]);
      if (u.length === 0 || u[0].role !== 'user') return res.status(403).json({ error: 'Forbidden' });
      await pool.query('DELETE FROM users WHERE id = ?', [id]);
    } else {
      return res.status(403).json({ error: 'Forbidden' });
    }
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Deletion failed' });
  }
});

// ==================== WAREHOUSES ====================

// list all warehouses
app.get('/api/warehouses', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM warehouses');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

// create new warehouse (admin/manager only)
app.post('/api/warehouses', checkAuth, async (req, res) => {
  if (!['admin','manager'].includes(req.session.role)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const { name, store, location, state, country, capacity, manager_id } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });
    const [result] = await pool.query(
      `INSERT INTO warehouses (name, store, location, state, country, capacity, manager_id)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, store || null, location || null, state || null, country || null, capacity || 0, manager_id || null]
    );
    const [row] = await pool.query('SELECT * FROM warehouses WHERE id = ?', [result.insertId]);
    res.json(row[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create warehouse' });
  }
});

// update warehouse
app.put('/api/warehouses/:id', checkAuth, async (req, res) => {
  if (!['admin','manager'].includes(req.session.role)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const id = req.params.id;
    const { name, store, location, state, country, capacity, manager_id } = req.body;
    await pool.query(
      `UPDATE warehouses SET name=?, store=?, location=?, state=?, country=?, capacity=?, manager_id=? WHERE id = ?`,
      [name, store || null, location || null, state || null, country || null, capacity || 0, manager_id || null, id]
    );
    const [row] = await pool.query('SELECT * FROM warehouses WHERE id = ?', [id]);
    res.json(row[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update warehouse' });
  }
});

// delete warehouse
app.delete('/api/warehouses/:id', checkAuth, async (req, res) => {
  if (req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const id = req.params.id;
    await pool.query('DELETE FROM warehouses WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete warehouse' });
  }
});

// ==================== INVENTORY (Product Catalog) ====================

app.get('/api/inventory', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT i.*, 
        COALESCE(SUM(s.quantity), 0) as total_quantity
       FROM inventory i
       LEFT JOIN stock s ON i.id = s.inventory_id
       WHERE i.user_id = ?
       GROUP BY i.id
       ORDER BY i.name ASC`,
      [req.session.userId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/items', checkAuth, async (req, res) => {
  try {
    const { name, sku, category, description, unit_price, reorder_level } = req.body;

    if (!name || !sku) {
      return res.status(400).json({ error: 'Name and SKU are required' });
    }

    const [result] = await pool.query(
      `INSERT INTO inventory (name, sku, category, description, unit_price, reorder_level, user_id)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, sku, category || null, description || null, unit_price || 0, reorder_level || 10, req.session.userId]
    );

    const [rows] = await pool.query('SELECT * FROM inventory WHERE id = ?', [result.insertId]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'SKU already exists' });
    }
    res.status(500).json({ error: 'Failed to create inventory item' });
  }
});

app.put('/api/items/:id', checkAuth, async (req, res) => {
  try {
    const id = req.params.id;
    const { name, sku, category, description, unit_price, reorder_level } = req.body;

    const [check] = await pool.query('SELECT user_id FROM inventory WHERE id = ?', [id]);
    if (check.length === 0 || check[0].user_id !== req.session.userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await pool.query(
      `UPDATE inventory 
       SET name = ?, sku = ?, category = ?, description = ?, unit_price = ?, reorder_level = ? 
       WHERE id = ?`,
      [name, sku, category, description, unit_price || 0, reorder_level || 10, id]
    );

    const [rows] = await pool.query('SELECT * FROM inventory WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update inventory item' });
  }
});

app.delete('/api/items/:id', checkAuth, async (req, res) => {
  try {
    const id = req.params.id;

    const [check] = await pool.query('SELECT user_id FROM inventory WHERE id = ?', [id]);
    if (check.length === 0 || check[0].user_id !== req.session.userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await pool.query('DELETE FROM stock WHERE inventory_id = ?', [id]);
    await pool.query('DELETE FROM inventory WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete inventory item' });
  }
});

// ==================== STOCK (Quantity Tracking by Warehouse) ====================

app.get('/api/stock', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT s.id, s.inventory_id, s.warehouse_id, s.quantity, 
              i.name, i.sku, i.reorder_level,
              w.name as warehouse_name, w.location as warehouse_location
       FROM stock s
       JOIN inventory i ON s.inventory_id = i.id
       JOIN warehouses w ON s.warehouse_id = w.id
       WHERE i.user_id = ?
       ORDER BY i.name, w.name`,
      [req.session.userId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.post('/api/stock', checkAuth, async (req, res) => {
  try {
    const { inventory_id, warehouse_id, quantity } = req.body;

    const [check] = await pool.query('SELECT user_id FROM inventory WHERE id = ?', [inventory_id]);
    if (check.length === 0 || check[0].user_id !== req.session.userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await pool.query(
      `INSERT INTO stock (inventory_id, warehouse_id, quantity) 
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE quantity = ?`,
      [inventory_id, warehouse_id, quantity || 0, quantity || 0]
    );

    const [rows] = await pool.query(
      'SELECT * FROM stock WHERE inventory_id = ? AND warehouse_id = ?',
      [inventory_id, warehouse_id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to add stock' });
  }
});

app.put('/api/stock/:id', checkAuth, async (req, res) => {
  try {
    const id = req.params.id;
    const { quantity } = req.body;
    const role = req.session.role;
    const userId = req.session.userId;
    const managerId = req.session.managerId;

    // Get stock record with warehouse and manager info
    const [stockRow] = await pool.query(
      `SELECT s.*, w.manager_id 
       FROM stock s
       JOIN warehouses w ON s.warehouse_id = w.id
       WHERE s.id = ?`,
      [id]
    );

    if (stockRow.length === 0) {
      return res.status(404).json({ error: 'Stock record not found' });
    }

    // Authorization check
    // Admin can update any stock
    // Manager can update stock in their warehouses
    // User can update stock in their manager's warehouses
    if (role === 'admin') {
      // OK - proceed
    } else if (role === 'manager') {
      if (stockRow[0].manager_id !== userId) {
        return res.status(403).json({ error: 'Not authorized for this warehouse' });
      }
    } else if (role === 'user') {
      if (stockRow[0].manager_id !== managerId) {
        return res.status(403).json({ error: 'Not authorized for this warehouse' });
      }
    } else {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await pool.query('UPDATE stock SET quantity = ? WHERE id = ?', [quantity || 0, id]);

    const [rows] = await pool.query('SELECT * FROM stock WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update stock' });
  }
});

// ==================== ALL STOCK SYSTEM VIEW (role-filtered) ====================
// Admin: sees all stock; Manager: sees stock for their warehouses; User: sees manager's warehouses
app.get('/api/all-stock', checkAuth, async (req, res) => {
  try {
    const role = req.session.role;
    const userId = req.session.userId;
    const managerId = req.session.managerId;
    
    let baseQuery = `
      SELECT s.id, s.inventory_id, s.warehouse_id, s.quantity, s.last_updated,
             i.id as item_id, i.name, i.sku, i.category, i.description, i.unit_price, i.reorder_level,
             w.id as wh_id, w.name as warehouse_name, w.store, w.location, w.state, w.country, 
             w.manager_id, u.fullname as manager_name
      FROM stock s
      JOIN inventory i ON s.inventory_id = i.id
      JOIN warehouses w ON s.warehouse_id = w.id
      LEFT JOIN users u ON w.manager_id = u.id
    `;
    
    let params = [];
    
    if (role === 'admin') {
      // Admin sees everything
      baseQuery += ' ORDER BY w.country, w.state, i.name ASC';
    } else if (role === 'manager') {
      // Manager sees only warehouses they manage
      baseQuery += ' WHERE w.manager_id = ? ORDER BY i.name ASC';
      params.push(userId);
    } else {
      // Regular user sees only their manager's warehouses
      baseQuery += ' WHERE w.manager_id = ? ORDER BY i.name ASC';
      params.push(managerId);
    }
    
    const [rows] = await pool.query(baseQuery, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch stock data' });
  }
});

// ==================== STATISTICS ====================

app.get('/api/stats', checkAuth, async (req, res) => {
  try {
    const [inventoryCount] = await pool.query(
      'SELECT COUNT(*) as count FROM inventory WHERE user_id = ?',
      [req.session.userId]
    );

    const [totalStock] = await pool.query(
      `SELECT COALESCE(SUM(s.quantity), 0) as total FROM stock s
       JOIN inventory i ON s.inventory_id = i.id
       WHERE i.user_id = ?`,
      [req.session.userId]
    );

    res.json({
      total_items: inventoryCount[0].count,
      total_quantity: totalStock[0].total,
      low_stock_count: lowStockCount[0].low_stock_count || 0
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get statistics' });
  }
});

// country-level statistics
app.get('/api/stats/countries', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT COALESCE(w.country, 'Unknown') AS country,
              COUNT(DISTINCT i.id) AS distinct_items,
              COALESCE(SUM(s.quantity),0) AS total_units,
              SUM(CASE WHEN s.quantity = 0 THEN 1 ELSE 0 END) AS out_of_stock_items
       FROM stock s
       JOIN inventory i ON s.inventory_id = i.id
       JOIN warehouses w ON s.warehouse_id = w.id
       GROUP BY w.country
       ORDER BY total_units DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get country stats' });
  }
});

// state-level statistics (optionally filtered by country)
app.get('/api/stats/states', checkAuth, async (req, res) => {
  try {
    const country = req.query.country || null;
    let q = `SELECT COALESCE(w.country, 'Unknown') as country, COALESCE(w.state,'Unknown') as state,
                    COUNT(DISTINCT i.id) AS distinct_items, COALESCE(SUM(s.quantity),0) AS total_units
             FROM stock s
             JOIN inventory i ON s.inventory_id = i.id
             JOIN warehouses w ON s.warehouse_id = w.id`;
    const params = [];
    if (country) { q += ' WHERE w.country = ?'; params.push(country); }
    q += ' GROUP BY w.country, w.state ORDER BY total_units DESC';
    const [rows] = await pool.query(q, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get state stats' });
  }
});

// ==================== LOCATIONS (Location-based Dashboard) ====================

// Get all locations with manager hierarchy
app.get('/api/locations', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT w.id, w.name as warehouse_name, w.state, w.country, 
              u.id as manager_id, u.username, u.fullname as manager_name,
              (SELECT COUNT(*) FROM users WHERE manager_id = u.id) as team_size,
              COALESCE(SUM(s.quantity), 0) as total_stock,
              COUNT(DISTINCT i.id) as distinct_items
       FROM warehouses w
       LEFT JOIN users u ON w.manager_id = u.id
       LEFT JOIN stock s ON s.warehouse_id = w.id
       LEFT JOIN inventory i ON s.inventory_id = i.id
       GROUP BY w.id
       ORDER BY w.state ASC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get locations' });
  }
});

// Get detailed location view with team and stock breakdown
app.get('/api/locations/:id', checkAuth, async (req, res) => {
  try {
    const locationId = req.params.id;
    
    // Get location warehouse details
    const [warehouse] = await pool.query(
      `SELECT w.id, w.name, w.state, w.country, w.capacity,
              u.id as manager_id, u.username, u.fullname as manager_name, u.email as manager_email
       FROM warehouses w
       LEFT JOIN users u ON w.manager_id = u.id
       WHERE w.id = ?`,
      [locationId]
    );

    if (warehouse.length === 0) {
      return res.status(404).json({ error: 'Location not found' });
    }

    // Get team members for this location
    const [team] = await pool.query(
      `SELECT id, username, fullname, email, role
       FROM users
       WHERE manager_id = (SELECT manager_id FROM warehouses WHERE id = ?)
       ORDER BY fullname ASC`,
      [locationId]
    );

    // Get stock breakdown for this location
    const [stock] = await pool.query(
      `SELECT i.id, i.name, i.sku, i.category, i.unit_price, 
              s.id as stock_id, s.quantity
       FROM inventory i
       LEFT JOIN stock s ON i.id = s.inventory_id AND s.warehouse_id = ?
       ORDER BY i.name ASC`,
      [locationId]
    );

    // Get location statistics
    const [stats] = await pool.query(
      `SELECT COALESCE(COUNT(DISTINCT i.id), 0) as distinct_items,
              COALESCE(SUM(s.quantity), 0) as total_units,
              SUM(CASE WHEN s.quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_items,
              SUM(CASE WHEN s.quantity < i.reorder_level THEN 1 ELSE 0 END) as low_stock_items
       FROM stock s
       JOIN inventory i ON s.inventory_id = i.id
       WHERE s.warehouse_id = ?`,
      [locationId]
    );

    res.json({
      warehouse: warehouse[0],
      team: team,
      stock: stock,
      stats: stats[0]
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get location details' });
  }
});

// Get location-based statistics (by state)
app.get('/api/locations/stats/regional', checkAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT w.state as region, COUNT(DISTINCT w.id) as warehouse_count,
              COUNT(DISTINCT u.id) as manager_count,
              COALESCE(SUM(s.quantity), 0) as total_stock,
              COUNT(DISTINCT i.id) as distinct_items
       FROM warehouses w
       LEFT JOIN users u ON w.manager_id = u.id
       LEFT JOIN stock s ON s.warehouse_id = w.id
       LEFT JOIN inventory i ON s.inventory_id = i.id
       GROUP BY w.state
       ORDER BY total_stock DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get regional stats' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
